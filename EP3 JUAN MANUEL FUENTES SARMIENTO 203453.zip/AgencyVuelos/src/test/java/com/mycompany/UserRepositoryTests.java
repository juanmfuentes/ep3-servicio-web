package com.mycompany;

import com.mycompany.model.Vuelo;
import com.mycompany.repository.VueloRepository;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;



@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class UserRepositoryTests {
    @Autowired private VueloRepository repo;

    @Test
    public void testAddNew() {
        Vuelo vuelo = new Vuelo();
        vuelo.setOrigen("Mexico");
        vuelo.setDestino("Merida");
       

        Vuelo savedVuelo = repo.save(vuelo);

        Assertions.assertThat(savedVuelo).isNotNull();
        Assertions.assertThat(savedVuelo.getId()).isGreaterThan(0);
    }

    @Test
    public void testListAll() {
        Iterable<Vuelo> vuelos = repo.findAll();
        Assertions.assertThat(vuelos).hasSizeGreaterThan(0);

        for (Vuelo vuelo: vuelos) {
            System.out.println(vuelo);
        }
    }

   
}
