package com.mycompany.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.model.Vuelo;
import com.mycompany.model.VueloNotFoundException;
import com.mycompany.repository.VueloRepository;

import java.util.List;
import java.util.Optional;

@Service
public class VueloService {
    @Autowired private VueloRepository repo;

    public List<Vuelo> listAll(String palabraClave) {
        if(palabraClave !=null){
            return repo.findAll(palabraClave);
        }
        
        return (List<Vuelo>) repo.findAll();
    }

    public void save(Vuelo vuelo) {
        repo.save(vuelo);
    }
    public void deleteAll() {
    repo.deleteAll();
}


    public Vuelo get(Integer id) throws VueloNotFoundException {
        Optional<Vuelo> result = repo.findById(id);
        if (result.isPresent()) {
            return result.get();
        }
        throw new VueloNotFoundException("Could not find any users with ID " + id);
    }

    public void delete(Integer id) throws VueloNotFoundException {
        Long count = repo.countById(id);
        if (count == null || count == 0) {
            throw new VueloNotFoundException("Could not find any users with ID " + id);
        }
        repo.deleteById(id);
    }
}
