package com.mycompany.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mycompany.model.Vuelo;

public interface VueloRepository extends JpaRepository<Vuelo, Integer> {
    public Long countById(Integer id);

    @Query("SELECT v FROM Vuelo v WHERE v.origen LIKE %?1%"
    +" OR v.destino LIKE %?1%"
    + "OR v.escalas LIKE %?1%")
    public List<Vuelo> findAll(String palabraClave);
}
