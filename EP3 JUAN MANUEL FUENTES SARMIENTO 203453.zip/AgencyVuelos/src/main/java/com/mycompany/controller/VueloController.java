package com.mycompany.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mycompany.model.Vuelo;
import com.mycompany.model.VueloNotFoundException;
import com.mycompany.service.VueloService;

import java.util.List;

@Controller
public class VueloController {
    @Autowired
    private VueloService service;

    @GetMapping("/vuelos")
    public String showUserList(Model model, @Param("palabraClave") String palabraClave) {
        List<Vuelo> listVuelos = service.listAll(palabraClave);
        model.addAttribute("listVuelos", listVuelos);
        model.addAttribute("palabraClave", palabraClave);
        model.addAttribute("pageTitle", "Gestionar Vuelos");

        return "vuelos";
    }

    @GetMapping("/vuelos/new")
    public String showNewForm(Model model) {
        model.addAttribute("vuelo", new Vuelo());
        model.addAttribute("pageTitle", "Nuevo Vuelo");
        return "vuelo_form";
    }

    @PostMapping("/vuelos/save")
    public String saveUser(Vuelo vuelo, RedirectAttributes ra) {
        service.save(vuelo);
        ra.addFlashAttribute("message", "El vuelo fue agregado correctamente.");
        return "redirect:/vuelos";
    }

    @GetMapping("/vuelos/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model, RedirectAttributes ra) {
        try {
            Vuelo vuelo = service.get(id);
            model.addAttribute("vuelo", vuelo);
            model.addAttribute("pageTitle", "Editar Vuelo (#" + id + ")");

            return "vuelo_form";
        } catch (VueloNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
            return "redirect:/vuelos";
        }
    }

    @GetMapping("/vuelos/delete/{id}")
    public String deleteVuelo(@PathVariable("id") Integer id, RedirectAttributes ra) {
        try {
            service.delete(id);
            ra.addFlashAttribute("message", "El Vuelo " + id + " fue eliminado.");
        } catch (VueloNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage());
        }
        return "redirect:/vuelos";
    }

    @GetMapping("/vuelos/delete/all")
    public String deleteAllVuelos(RedirectAttributes ra) {
        service.deleteAll();
        ra.addFlashAttribute("message", "Se eliminaron todos los vuelos.");
        return "redirect:/vuelos";
    }
}
