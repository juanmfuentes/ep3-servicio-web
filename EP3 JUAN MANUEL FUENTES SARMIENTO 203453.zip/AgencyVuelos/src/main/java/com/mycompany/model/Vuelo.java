package com.mycompany.model;

import javax.persistence.*;

@Entity
@Table(name = "vuelos")
public class Vuelo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, unique = true, length = 250)
    private String origen;

    @Column(length = 250, nullable = false)
    private String destino;
    
    @Column(length = 250, nullable = false)
    private String compania;

    @Column(nullable = false, name = "precio")
    private float precio;

    @Column(nullable = false, name = "escala")
    private int escalas;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setCompania(String compania) {
        this.compania = compania;
    }

        public String getCompania() {
        return compania;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getEscalas() {
        return escalas;
    }

    public void setEscalas(int escalas) {
        this.escalas = escalas;
    }

  
    @Override
    public String toString() {
        return "Vuelo{" +
                "id=" + id +
                ", origen='" + origen + '\'' +
                ", destino='" + destino+ '\'' +
                ",compania=" + compania+ '\''+
                ", precio='" + precio + '\'' +
                ", escalas='" + escalas + '\'' +
                '}';
    }



}
