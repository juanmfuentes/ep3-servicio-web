package com.mycompany.model;

public class VueloNotFoundException extends Throwable {
    public VueloNotFoundException(String message) {
        super(message);
    }
}
