# spring-boot-crud-intellij
Sample IntelliJ IDEA Project to learn Spring Boot CRUD
### Watch coding in action on YouTube: [Spring Boot CRUD Tutorial with IntelliJ IDEA, MySQL, JPA, Hibernate, Thymeleaf and Bootstrap](https://youtu.be/u8a25mQcMOI)
